# Commands
To Install the Dependencies
`npm install`

To Start and Compile the app.ts
`npm run start`

To Start nodemon and run from app.ts
`npm run dev`

To Build from Typescript and Output in dist
`npm run build`

To Build Docker
`docker-compose up --build`

PostMan Collection 
`https://www.getpostman.com/collections/3a196ba3d1d6d6a8df88`