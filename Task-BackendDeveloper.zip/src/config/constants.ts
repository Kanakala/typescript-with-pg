export const tokenTypes = {
  ACCESS: 'access',
  REFRESH: 'refresh',
};
